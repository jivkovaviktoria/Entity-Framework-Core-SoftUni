﻿namespace ProductShop.InputModels
{
    public class CategoryProductInputModel
    {
        public int CategoryId { get; set; }
        public int ProductId { get; set; }
    }
}