﻿namespace ProductShop.InputModels
{
    public class CategoryInputModel
    {
        public string Name { get; set; }
    }
}