﻿namespace Trucks.Data.Models.Enums
{
    public enum CategoryType
    {
        Flatbed,
        Jumbo,
        Refrigerated,
        Semi
    }
}