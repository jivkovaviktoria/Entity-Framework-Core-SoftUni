﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Footballers.Data.Models
{
    public class TeamFootballer
    {
        public int TeamId { get; set; }
        
        [ForeignKey(nameof(TeamId))]
        public Team Team { get; set; }

        public int FootballerId { get; set; }
        
        [ForeignKey(nameof(FootballerId))]
        public Footballer Footballer { get; set; }
    }
}

// TeamId – integer, Primary Key, foreign key (required)
//     Team – Team
//     FootballerId – integer, Primary Key, foreign key (required)
//     Footballer – Footballer